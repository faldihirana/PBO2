#Konversi Suhu Celcius Ke Fahrenheit:
C = 75
F = (9/5) * C + 32
print("konversi ",C, "derajat celcius adalah ",F, "derajat fahrenheit \n")
#Konversi Suhu Celcius Ke Reamur:
C = 60
R = 4/5 * C
print("konversi ",C, "derajat celcius adalah ",R, "derajat Reamur \n")
#Konversi Suhu Celcius Ke Kelvin:
C = 90
K = C + 273
print("konversi ",C, "derajat celcius adalah ",K, "derajat Kelvin \n")